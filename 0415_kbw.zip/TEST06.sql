SELECT username,
       expiry_date,
       default_tablespace,
       temporary_tablespace,
       profile,
       authentication_type
FROM dba_users;